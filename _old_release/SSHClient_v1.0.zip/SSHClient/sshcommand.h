#ifndef SSHCOMMAND_H
#define SSHCOMMAND_H

#include <QCoreApplication>
#include <QProcess>
#include <QDebug>
#include <QFile>
#include <QDir>
#include <QTemporaryDir>
#include <QTemporaryFile>

class SshCommand : public QObject
{
    Q_OBJECT
public:
    SshCommand(QString host, QString user, QString password = "") :
        host(host), user(user), password(password),
        keyPath(QDir::homePath() + "/.ssh/id_rsa")
    {
        qDebug() << "[初始化] 创建SSH命令对象，主机:" << host << "，用户:" << user;
        if(!password.isEmpty())
        {
            qDebug() << "[初始化] 已提供密码(安全提示: 建议使用密钥认证替代密码)";
        }
    }
private:
    QString host;
    QString user;
    QString password;
    QString keyPath;
};
#endif // SSHCOMMAND_H
