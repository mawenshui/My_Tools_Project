/****************************************************************************
** Meta object code from reading C++ file 'sendworker.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../orderSend/sendworker.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sendworker.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SendWorker_t {
    QByteArrayData data[30];
    char stringdata0[322];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SendWorker_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SendWorker_t qt_meta_stringdata_SendWorker = {
    {
QT_MOC_LITERAL(0, 0, 10), // "SendWorker"
QT_MOC_LITERAL(1, 11, 10), // "logMessage"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 5), // "level"
QT_MOC_LITERAL(4, 29, 7), // "message"
QT_MOC_LITERAL(5, 37, 8), // "finished"
QT_MOC_LITERAL(6, 46, 11), // "sendCommand"
QT_MOC_LITERAL(7, 58, 7), // "address"
QT_MOC_LITERAL(8, 66, 4), // "port"
QT_MOC_LITERAL(9, 71, 7), // "comname"
QT_MOC_LITERAL(10, 79, 17), // "QMap<QString,int>"
QT_MOC_LITERAL(11, 97, 12), // "commandIdMap"
QT_MOC_LITERAL(12, 110, 9), // "workIdMap"
QT_MOC_LITERAL(13, 120, 20), // "QMap<QString,double>"
QT_MOC_LITERAL(14, 141, 7), // "timeMap"
QT_MOC_LITERAL(15, 149, 6), // "comCrc"
QT_MOC_LITERAL(16, 156, 5), // "reCrc"
QT_MOC_LITERAL(17, 162, 8), // "comReply"
QT_MOC_LITERAL(18, 171, 10), // "havereturn"
QT_MOC_LITERAL(19, 182, 7), // "ReReply"
QT_MOC_LITERAL(20, 190, 8), // "replycrc"
QT_MOC_LITERAL(21, 199, 9), // "returnErr"
QT_MOC_LITERAL(22, 209, 7), // "noShake"
QT_MOC_LITERAL(23, 217, 14), // "isReplyTimeout"
QT_MOC_LITERAL(24, 232, 15), // "isReturnTimeout"
QT_MOC_LITERAL(25, 248, 16), // "isReReplyTimeout"
QT_MOC_LITERAL(26, 265, 14), // "replyTimeoutMs"
QT_MOC_LITERAL(27, 280, 15), // "returnTimeoutMs"
QT_MOC_LITERAL(28, 296, 16), // "reReplyTimeoutMs"
QT_MOC_LITERAL(29, 313, 8) // "flowMode"

    },
    "SendWorker\0logMessage\0\0level\0message\0"
    "finished\0sendCommand\0address\0port\0"
    "comname\0QMap<QString,int>\0commandIdMap\0"
    "workIdMap\0QMap<QString,double>\0timeMap\0"
    "comCrc\0reCrc\0comReply\0havereturn\0"
    "ReReply\0replycrc\0returnErr\0noShake\0"
    "isReplyTimeout\0isReturnTimeout\0"
    "isReReplyTimeout\0replyTimeoutMs\0"
    "returnTimeoutMs\0reReplyTimeoutMs\0"
    "flowMode"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SendWorker[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   29,    2, 0x06 /* Public */,
       5,    0,   34,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,   21,   35,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    4,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::UShort, QMetaType::QString, 0x80000000 | 10, 0x80000000 | 10, 0x80000000 | 13, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    7,    8,    9,   11,   12,   14,   15,   16,   17,   18,   19,   20,   21,   22,   23,   24,   25,   26,   27,   28,   29,

       0        // eod
};

void SendWorker::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SendWorker *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->logMessage((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 1: _t->finished(); break;
        case 2: _t->sendCommand((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< quint16(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< const QMap<QString,int>(*)>(_a[4])),(*reinterpret_cast< const QMap<QString,int>(*)>(_a[5])),(*reinterpret_cast< const QMap<QString,double>(*)>(_a[6])),(*reinterpret_cast< bool(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10])),(*reinterpret_cast< bool(*)>(_a[11])),(*reinterpret_cast< bool(*)>(_a[12])),(*reinterpret_cast< bool(*)>(_a[13])),(*reinterpret_cast< bool(*)>(_a[14])),(*reinterpret_cast< bool(*)>(_a[15])),(*reinterpret_cast< bool(*)>(_a[16])),(*reinterpret_cast< bool(*)>(_a[17])),(*reinterpret_cast< int(*)>(_a[18])),(*reinterpret_cast< int(*)>(_a[19])),(*reinterpret_cast< int(*)>(_a[20])),(*reinterpret_cast< int(*)>(_a[21]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SendWorker::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SendWorker::logMessage)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (SendWorker::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SendWorker::finished)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject SendWorker::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_SendWorker.data,
    qt_meta_data_SendWorker,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SendWorker::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SendWorker::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SendWorker.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int SendWorker::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void SendWorker::logMessage(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SendWorker::finished()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
