/****************************************************************************
** Meta object code from reading C++ file 'ordersendwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../orderSend/ordersendwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ordersendwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_OrderSendWidget_t {
    QByteArrayData data[41];
    char stringdata0[586];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_OrderSendWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_OrderSendWidget_t qt_meta_stringdata_OrderSendWidget = {
    {
QT_MOC_LITERAL(0, 0, 15), // "OrderSendWidget"
QT_MOC_LITERAL(1, 16, 10), // "logMessage"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 5), // "level"
QT_MOC_LITERAL(4, 34, 7), // "message"
QT_MOC_LITERAL(5, 42, 16), // "startSendCommand"
QT_MOC_LITERAL(6, 59, 7), // "address"
QT_MOC_LITERAL(7, 67, 4), // "port"
QT_MOC_LITERAL(8, 72, 7), // "comname"
QT_MOC_LITERAL(9, 80, 17), // "QMap<QString,int>"
QT_MOC_LITERAL(10, 98, 12), // "commandIdMap"
QT_MOC_LITERAL(11, 111, 9), // "workIdMap"
QT_MOC_LITERAL(12, 121, 20), // "QMap<QString,double>"
QT_MOC_LITERAL(13, 142, 7), // "timeMap"
QT_MOC_LITERAL(14, 150, 6), // "comCrc"
QT_MOC_LITERAL(15, 157, 5), // "reCrc"
QT_MOC_LITERAL(16, 163, 8), // "comReply"
QT_MOC_LITERAL(17, 172, 10), // "havereturn"
QT_MOC_LITERAL(18, 183, 7), // "ReReply"
QT_MOC_LITERAL(19, 191, 8), // "replycrc"
QT_MOC_LITERAL(20, 200, 9), // "returnErr"
QT_MOC_LITERAL(21, 210, 7), // "noShake"
QT_MOC_LITERAL(22, 218, 14), // "isReplyTimeout"
QT_MOC_LITERAL(23, 233, 15), // "isReturnTimeout"
QT_MOC_LITERAL(24, 249, 16), // "isReReplyTimeout"
QT_MOC_LITERAL(25, 266, 14), // "replyTimeoutMs"
QT_MOC_LITERAL(26, 281, 15), // "returnTimeoutMs"
QT_MOC_LITERAL(27, 297, 16), // "reReplyTimeoutMs"
QT_MOC_LITERAL(28, 314, 8), // "flowMode"
QT_MOC_LITERAL(29, 323, 26), // "on_pushButtonstart_clicked"
QT_MOC_LITERAL(30, 350, 29), // "on_pushButtonClearLog_clicked"
QT_MOC_LITERAL(31, 380, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(32, 402, 25), // "on_pushButtonStop_clicked"
QT_MOC_LITERAL(33, 428, 24), // "on_btnLoopSingle_clicked"
QT_MOC_LITERAL(34, 453, 18), // "handleSendFinished"
QT_MOC_LITERAL(35, 472, 16), // "handleLogMessage"
QT_MOC_LITERAL(36, 489, 19), // "sendNextLoopCommand"
QT_MOC_LITERAL(37, 509, 19), // "filterComboBoxItems"
QT_MOC_LITERAL(38, 529, 10), // "filterText"
QT_MOC_LITERAL(39, 540, 24), // "onOpenMultiplierSettings"
QT_MOC_LITERAL(40, 565, 20) // "onOpenMultiplierHelp"

    },
    "OrderSendWidget\0logMessage\0\0level\0"
    "message\0startSendCommand\0address\0port\0"
    "comname\0QMap<QString,int>\0commandIdMap\0"
    "workIdMap\0QMap<QString,double>\0timeMap\0"
    "comCrc\0reCrc\0comReply\0havereturn\0"
    "ReReply\0replycrc\0returnErr\0noShake\0"
    "isReplyTimeout\0isReturnTimeout\0"
    "isReReplyTimeout\0replyTimeoutMs\0"
    "returnTimeoutMs\0reReplyTimeoutMs\0"
    "flowMode\0on_pushButtonstart_clicked\0"
    "on_pushButtonClearLog_clicked\0"
    "on_pushButton_clicked\0on_pushButtonStop_clicked\0"
    "on_btnLoopSingle_clicked\0handleSendFinished\0"
    "handleLogMessage\0sendNextLoopCommand\0"
    "filterComboBoxItems\0filterText\0"
    "onOpenMultiplierSettings\0onOpenMultiplierHelp"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_OrderSendWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   79,    2, 0x06 /* Public */,
       5,   21,   84,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      29,    0,  127,    2, 0x08 /* Private */,
      30,    0,  128,    2, 0x08 /* Private */,
      31,    0,  129,    2, 0x08 /* Private */,
      32,    0,  130,    2, 0x08 /* Private */,
      33,    0,  131,    2, 0x08 /* Private */,
      34,    0,  132,    2, 0x08 /* Private */,
      35,    2,  133,    2, 0x08 /* Private */,
      36,    0,  138,    2, 0x08 /* Private */,
      37,    1,  139,    2, 0x08 /* Private */,
      39,    0,  142,    2, 0x08 /* Private */,
      40,    0,  143,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    4,
    QMetaType::Void, QMetaType::QString, QMetaType::UShort, QMetaType::QString, 0x80000000 | 9, 0x80000000 | 9, 0x80000000 | 12, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    6,    7,    8,   10,   11,   13,   14,   15,   16,   17,   18,   19,   20,   21,   22,   23,   24,   25,   26,   27,   28,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    4,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   38,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void OrderSendWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<OrderSendWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->logMessage((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 1: _t->startSendCommand((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< quint16(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< const QMap<QString,int>(*)>(_a[4])),(*reinterpret_cast< const QMap<QString,int>(*)>(_a[5])),(*reinterpret_cast< const QMap<QString,double>(*)>(_a[6])),(*reinterpret_cast< bool(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10])),(*reinterpret_cast< bool(*)>(_a[11])),(*reinterpret_cast< bool(*)>(_a[12])),(*reinterpret_cast< bool(*)>(_a[13])),(*reinterpret_cast< bool(*)>(_a[14])),(*reinterpret_cast< bool(*)>(_a[15])),(*reinterpret_cast< bool(*)>(_a[16])),(*reinterpret_cast< bool(*)>(_a[17])),(*reinterpret_cast< int(*)>(_a[18])),(*reinterpret_cast< int(*)>(_a[19])),(*reinterpret_cast< int(*)>(_a[20])),(*reinterpret_cast< int(*)>(_a[21]))); break;
        case 2: _t->on_pushButtonstart_clicked(); break;
        case 3: _t->on_pushButtonClearLog_clicked(); break;
        case 4: _t->on_pushButton_clicked(); break;
        case 5: _t->on_pushButtonStop_clicked(); break;
        case 6: _t->on_btnLoopSingle_clicked(); break;
        case 7: _t->handleSendFinished(); break;
        case 8: _t->handleLogMessage((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 9: _t->sendNextLoopCommand(); break;
        case 10: _t->filterComboBoxItems((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->onOpenMultiplierSettings(); break;
        case 12: _t->onOpenMultiplierHelp(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (OrderSendWidget::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&OrderSendWidget::logMessage)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (OrderSendWidget::*)(const QString & , quint16 , const QString & , const QMap<QString,int> & , const QMap<QString,int> & , const QMap<QString,double> & , bool , bool , bool , bool , bool , bool , bool , bool , bool , bool , bool , int , int , int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&OrderSendWidget::startSendCommand)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject OrderSendWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_OrderSendWidget.data,
    qt_meta_data_OrderSendWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *OrderSendWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *OrderSendWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_OrderSendWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int OrderSendWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void OrderSendWidget::logMessage(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void OrderSendWidget::startSendCommand(const QString & _t1, quint16 _t2, const QString & _t3, const QMap<QString,int> & _t4, const QMap<QString,int> & _t5, const QMap<QString,double> & _t6, bool _t7, bool _t8, bool _t9, bool _t10, bool _t11, bool _t12, bool _t13, bool _t14, bool _t15, bool _t16, bool _t17, int _t18, int _t19, int _t20, int _t21)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)), const_cast<void*>(reinterpret_cast<const void*>(&_t6)), const_cast<void*>(reinterpret_cast<const void*>(&_t7)), const_cast<void*>(reinterpret_cast<const void*>(&_t8)), const_cast<void*>(reinterpret_cast<const void*>(&_t9)), const_cast<void*>(reinterpret_cast<const void*>(&_t10)), const_cast<void*>(reinterpret_cast<const void*>(&_t11)), const_cast<void*>(reinterpret_cast<const void*>(&_t12)), const_cast<void*>(reinterpret_cast<const void*>(&_t13)), const_cast<void*>(reinterpret_cast<const void*>(&_t14)), const_cast<void*>(reinterpret_cast<const void*>(&_t15)), const_cast<void*>(reinterpret_cast<const void*>(&_t16)), const_cast<void*>(reinterpret_cast<const void*>(&_t17)), const_cast<void*>(reinterpret_cast<const void*>(&_t18)), const_cast<void*>(reinterpret_cast<const void*>(&_t19)), const_cast<void*>(reinterpret_cast<const void*>(&_t20)), const_cast<void*>(reinterpret_cast<const void*>(&_t21)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
