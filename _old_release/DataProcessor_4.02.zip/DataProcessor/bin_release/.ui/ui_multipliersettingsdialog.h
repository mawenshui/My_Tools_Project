/********************************************************************************
** Form generated from reading UI file 'multipliersettingsdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MULTIPLIERSETTINGSDIALOG_H
#define UI_MULTIPLIERSETTINGSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_MultiplierSettingsDialog
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *titleLabel;
    QFrame *settingsPanel;
    QFormLayout *formLayout;
    QLabel *labelFast;
    QDoubleSpinBox *fastSpinBox;
    QLabel *labelNormal;
    QDoubleSpinBox *normalSpinBox;
    QLabel *labelChecked;
    QDoubleSpinBox *checkedSpinBox;
    QLabel *tipLabel;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *MultiplierSettingsDialog)
    {
        if (MultiplierSettingsDialog->objectName().isEmpty())
            MultiplierSettingsDialog->setObjectName(QString::fromUtf8("MultiplierSettingsDialog"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MultiplierSettingsDialog->sizePolicy().hasHeightForWidth());
        MultiplierSettingsDialog->setSizePolicy(sizePolicy);
        verticalLayout = new QVBoxLayout(MultiplierSettingsDialog);
        verticalLayout->setSpacing(12);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(16, 16, 16, 16);
        titleLabel = new QLabel(MultiplierSettingsDialog);
        titleLabel->setObjectName(QString::fromUtf8("titleLabel"));

        verticalLayout->addWidget(titleLabel);

        settingsPanel = new QFrame(MultiplierSettingsDialog);
        settingsPanel->setObjectName(QString::fromUtf8("settingsPanel"));
        settingsPanel->setFrameShape(QFrame::StyledPanel);
        formLayout = new QFormLayout(settingsPanel);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setHorizontalSpacing(10);
        formLayout->setVerticalSpacing(10);
        formLayout->setContentsMargins(12, 12, 12, 12);
        labelFast = new QLabel(settingsPanel);
        labelFast->setObjectName(QString::fromUtf8("labelFast"));

        formLayout->setWidget(0, QFormLayout::LabelRole, labelFast);

        fastSpinBox = new QDoubleSpinBox(settingsPanel);
        fastSpinBox->setObjectName(QString::fromUtf8("fastSpinBox"));

        formLayout->setWidget(0, QFormLayout::FieldRole, fastSpinBox);

        labelNormal = new QLabel(settingsPanel);
        labelNormal->setObjectName(QString::fromUtf8("labelNormal"));

        formLayout->setWidget(1, QFormLayout::LabelRole, labelNormal);

        normalSpinBox = new QDoubleSpinBox(settingsPanel);
        normalSpinBox->setObjectName(QString::fromUtf8("normalSpinBox"));

        formLayout->setWidget(1, QFormLayout::FieldRole, normalSpinBox);

        labelChecked = new QLabel(settingsPanel);
        labelChecked->setObjectName(QString::fromUtf8("labelChecked"));

        formLayout->setWidget(2, QFormLayout::LabelRole, labelChecked);

        checkedSpinBox = new QDoubleSpinBox(settingsPanel);
        checkedSpinBox->setObjectName(QString::fromUtf8("checkedSpinBox"));

        formLayout->setWidget(2, QFormLayout::FieldRole, checkedSpinBox);


        verticalLayout->addWidget(settingsPanel);

        tipLabel = new QLabel(MultiplierSettingsDialog);
        tipLabel->setObjectName(QString::fromUtf8("tipLabel"));
        tipLabel->setWordWrap(true);

        verticalLayout->addWidget(tipLabel);

        buttonBox = new QDialogButtonBox(MultiplierSettingsDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setStandardButtons(QDialogButtonBox::Ok|QDialogButtonBox::Cancel);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(MultiplierSettingsDialog);

        QMetaObject::connectSlotsByName(MultiplierSettingsDialog);
    } // setupUi

    void retranslateUi(QDialog *MultiplierSettingsDialog)
    {
        MultiplierSettingsDialog->setWindowTitle(QApplication::translate("MultiplierSettingsDialog", "\345\200\215\347\216\207\350\256\276\347\275\256", nullptr));
        titleLabel->setText(QApplication::translate("MultiplierSettingsDialog", "\345\200\215\347\216\207\350\256\276\347\275\256", nullptr));
        titleLabel->setObjectName(QApplication::translate("MultiplierSettingsDialog", "dialogTitle", nullptr));
        labelFast->setText(QApplication::translate("MultiplierSettingsDialog", "\345\277\253\351\200\237\346\265\201\347\250\213\345\200\215\347\216\207", nullptr));
        labelNormal->setText(QApplication::translate("MultiplierSettingsDialog", "\346\255\243\345\270\270\346\265\201\347\250\213\345\200\215\347\216\207", nullptr));
        labelChecked->setText(QApplication::translate("MultiplierSettingsDialog", "\345\213\276\351\200\211\350\266\205\346\227\266\345\200\215\347\216\207", nullptr));
        tipLabel->setText(QApplication::translate("MultiplierSettingsDialog", "\350\214\203\345\233\264\357\274\2320.001\342\200\2233.000\357\274\214\350\266\205\345\207\272\350\214\203\345\233\264\345\260\206\346\227\240\346\263\225\344\277\235\345\255\230\343\200\202", nullptr));
        tipLabel->setObjectName(QApplication::translate("MultiplierSettingsDialog", "dialogSubtleText", nullptr));
        buttonBox->setObjectName(QApplication::translate("MultiplierSettingsDialog", "dialogButtons", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MultiplierSettingsDialog: public Ui_MultiplierSettingsDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MULTIPLIERSETTINGSDIALOG_H
