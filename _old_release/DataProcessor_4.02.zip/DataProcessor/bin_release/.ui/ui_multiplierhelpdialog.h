/********************************************************************************
** Form generated from reading UI file 'multiplierhelpdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MULTIPLIERHELPDIALOG_H
#define UI_MULTIPLIERHELPDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MultiplierHelpDialog
{
public:
    QGridLayout *gridLayout;
    QLabel *dialogTitle;
    QScrollArea *dialogScrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_2;
    QLabel *dialogBodyText;
    QHBoxLayout *horizontalLayout;
    QPushButton *restoreButton;
    QSpacerItem *horizontalSpacer;
    QDialogButtonBox *dialogButtons;

    void setupUi(QDialog *MultiplierHelpDialog)
    {
        if (MultiplierHelpDialog->objectName().isEmpty())
            MultiplierHelpDialog->setObjectName(QString::fromUtf8("MultiplierHelpDialog"));
        MultiplierHelpDialog->resize(527, 289);
        gridLayout = new QGridLayout(MultiplierHelpDialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        dialogTitle = new QLabel(MultiplierHelpDialog);
        dialogTitle->setObjectName(QString::fromUtf8("dialogTitle"));

        gridLayout->addWidget(dialogTitle, 0, 0, 1, 1);

        dialogScrollArea = new QScrollArea(MultiplierHelpDialog);
        dialogScrollArea->setObjectName(QString::fromUtf8("dialogScrollArea"));
        dialogScrollArea->setFrameShape(QFrame::NoFrame);
        dialogScrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 509, 225));
        verticalLayout_2 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        dialogBodyText = new QLabel(scrollAreaWidgetContents);
        dialogBodyText->setObjectName(QString::fromUtf8("dialogBodyText"));
        dialogBodyText->setWordWrap(true);

        verticalLayout_2->addWidget(dialogBodyText);

        dialogScrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout->addWidget(dialogScrollArea, 1, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        restoreButton = new QPushButton(MultiplierHelpDialog);
        restoreButton->setObjectName(QString::fromUtf8("restoreButton"));

        horizontalLayout->addWidget(restoreButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        dialogButtons = new QDialogButtonBox(MultiplierHelpDialog);
        dialogButtons->setObjectName(QString::fromUtf8("dialogButtons"));
        dialogButtons->setStandardButtons(QDialogButtonBox::Close);

        horizontalLayout->addWidget(dialogButtons);


        gridLayout->addLayout(horizontalLayout, 2, 0, 1, 1);


        retranslateUi(MultiplierHelpDialog);

        QMetaObject::connectSlotsByName(MultiplierHelpDialog);
    } // setupUi

    void retranslateUi(QDialog *MultiplierHelpDialog)
    {
        MultiplierHelpDialog->setWindowTitle(QApplication::translate("MultiplierHelpDialog", "\345\200\215\347\216\207\345\270\256\345\212\251", nullptr));
        dialogTitle->setText(QApplication::translate("MultiplierHelpDialog", "\345\200\215\347\216\207\350\257\264\346\230\216\344\270\216\346\223\215\344\275\234", nullptr));
        dialogBodyText->setText(QApplication::translate("MultiplierHelpDialog", "\350\257\264\346\230\216\346\226\207\346\234\254", nullptr));
        restoreButton->setText(QApplication::translate("MultiplierHelpDialog", "\346\201\242\345\244\215\351\273\230\350\256\244", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MultiplierHelpDialog: public Ui_MultiplierHelpDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MULTIPLIERHELPDIALOG_H
