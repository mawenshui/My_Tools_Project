#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "floatwindow.h"

#include <QMessageBox>
#include <QInputDialog>
#include <QMenu>
#include <QCloseEvent>
#include <QSettings>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTimer>
#include <QScreen>
#include <QGuiApplication>
#include <QStandardPaths>
#include <QDir>
#include <QRegExp>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_configManager(new ConfigManager(this)),
    m_quickMenu(nullptr),
    m_floatWindow(new FloatWindow(this)),
    m_trayIcon(new QSystemTrayIcon(this)),
    m_singleInstanceLock(APP_NAME + QString::number(QCoreApplication::applicationPid())),
    m_floatVisible(true),
    m_autostart(false)
{
    Logger::info("开始初始化主窗口");
    ui->setupUi(this);
    //初始化日志系统
    QDir logsDir(QDir::toNativeSeparators(QCoreApplication::applicationDirPath() + "/logs/"));
    if (!logsDir.exists() && !logsDir.mkpath("."))
    {
        Logger::error(QString("无法创建日志文件夹: %1").arg(logsDir.path()));
        QMessageBox::warning(this, "错误", QString("无法创建日志文件夹: ") + logsDir.path());
        Logger::instance()->init();
    }
    else
    {
        Logger::info(QString("日志目录初始化成功: %1").arg(logsDir.path()));
    }
    Logger::instance()->init(logsDir.path(), "MainWindow");
    //1. 检查单实例
    Logger::debug("开始检查单实例运行");
    if (!checkSingleInstance())
    {
        Logger::critical("单实例检查失败，程序将退出");
        return;
    }
    //确保先初始化菜单
    Logger::debug("初始化快速应用配置菜单");
    m_quickMenu = new QMenu("快速应用配置", this);
    //2. 初始化UI组件
    Logger::info("开始初始化UI组件");
    setupUi();
    //3. 初始化配置和网络接口
    Logger::info("开始初始化应用程序配置");
    initializeApplication();
    //4. 初始化系统托盘和悬浮窗
    Logger::info("初始化系统托盘和悬浮窗");
    setupTrayIcon();
    if (m_floatVisible)
    {
        Logger::debug("显示悬浮窗");
        m_floatWindow->show();
    }
    //5. 最后建立连接
    Logger::debug("建立信号槽连接");
    setupConnections();
    Logger::info("主窗口初始化完成");
}

MainWindow::~MainWindow()
{
    Logger::info("开始销毁主窗口");
    //安全删除菜单
    if (!m_quickMenu)
    {
        Logger::debug("删除快速菜单");
        m_quickMenu->deleteLater();
    }
    Logger::debug("保存窗口状态");
    saveWindowState();
    delete ui;
    Logger::info("主窗口销毁完成");
}

bool MainWindow::checkSingleInstance()
{
    Logger::debug("检查程序是否已运行");
    if (m_singleInstanceLock.attach())
    {
        Logger::warning("检测到程序已经在运行中");
        QMessageBox::critical(nullptr, "错误", "程序已经在运行中");
        qApp->quit();
        return false;
    }
    if (!m_singleInstanceLock.create(1))
    {
        Logger::error("无法创建单实例锁");
        QMessageBox::critical(nullptr, "错误", "无法创建单实例锁");
        return false;
    }
    Logger::info("单实例检查通过");
    return true;
}

void MainWindow::setupUi()
{
    Logger::debug("设置UI初始状态");
    //初始状态
    ui->dhcpRadio->setChecked(true);
    onIpMethodToggled(true);
    //设置图标
    setWindowIcon(QIcon(":/images/images/icon.png"));
    //恢复窗口状态
    Logger::debug("恢复窗口状态");
    restoreWindowState();
    //初始化状态栏
    ui->statusBar->showMessage("就绪", 2000);
    Logger::info("UI初始化完成");
}

void MainWindow::setupConnections()
{
    Logger::debug("开始建立信号槽连接");
    //配置列表
    connect(ui->configList, &QListWidget::itemClicked, this, &MainWindow::onConfigSelected);
    //网络接口
    connect(ui->interfaceCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onInterfaceChanged);
    //IP方法
    connect(ui->dhcpRadio, &QRadioButton::toggled, this, &MainWindow::onIpMethodToggled);
    //按钮
    connect(ui->addButton, &QPushButton::clicked, this, &MainWindow::onAddConfig);
    connect(ui->updateButton, &QPushButton::clicked, this, &MainWindow::onUpdateConfig);
    connect(ui->deleteButton, &QPushButton::clicked, this, &MainWindow::onDeleteConfig);
    connect(ui->applyButton, &QPushButton::clicked, this, &MainWindow::onApplyConfig);
    connect(ui->refreshButton, &QPushButton::clicked, this, &MainWindow::updateInterfaces);
    //配置管理器的信号
    connect(m_configManager, &ConfigManager::configApplied, this, [this](bool success, const QString & message)
    {
        if (success)
        {
            Logger::info("配置应用成功");
            ui->statusBar->showMessage("配置已应用", 2000);
            updateQuickMenu();
            m_floatWindow->update();
        }
        else
        {
            Logger::error(QString("配置应用失败: %1").arg(message));
            QMessageBox::warning(this, "应用失败", message);
        }
    });
    connect(m_configManager, &ConfigManager::errorOccurred, this, [this](const QString & error)
    {
        Logger::error(QString("配置管理器错误: %1").arg(error));
        QMessageBox::critical(this, "错误", error);
    });
    connect(m_configManager, &ConfigManager::adminStatusChanged, this, [this](bool isAdmin)
    {
        ui->applyButton->setEnabled(isAdmin);
        ui->addButton->setEnabled(isAdmin);
        ui->updateButton->setEnabled(isAdmin);
        ui->deleteButton->setEnabled(isAdmin);
        if (isAdmin)
        {
            Logger::info("已获取管理员权限");
            ui->statusBar->showMessage("已获取管理员权限", 2000);
        }
        else
        {
            Logger::warning("管理员权限已丢失");
        }
    });
    //浮动窗口
    connect(m_floatWindow, &FloatWindow::doubleClicked, this, &MainWindow::showNormal);
    connect(m_floatWindow, &FloatWindow::showContextMenu, this, &MainWindow::showFloatWindowMenu);
    //初始化系统托盘
    setupTrayIcon();
    Logger::info("信号槽连接建立完成");
}

void MainWindow::initializeApplication()
{
    Logger::info("开始初始化应用程序");
    //加载配置
    if (!m_configManager->loadConfigs())
    {
        Logger::warning("加载配置文件失败，将使用空配置");
        QMessageBox::warning(this, "警告", "加载配置文件失败，将使用空配置");
    }
    else
    {
        Logger::info("配置文件加载成功");
    }
    //更新网络接口
    Logger::debug("更新网络接口列表");
    updateInterfaces();
    //检查开机启动
    QSettings settings("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run", QSettings::NativeFormat);
    m_autostart = settings.contains(APP_NAME);
    Logger::info(QString("开机自启动状态: %1").arg(m_autostart ? "已启用" : "已禁用"));
    //初始化浮动窗口
    QSettings windowSettings;
    QPoint floatWindowPos = windowSettings.value("floatWindowPos", QPoint(100, 100)).toPoint();
    m_floatWindow->move(floatWindowPos);
    m_floatVisible = windowSettings.value("floatWindowVisible", true).toBool();
    if (m_floatVisible)
    {
        Logger::debug("显示浮动窗口");
        m_floatWindow->show();
    }
    Logger::info("应用程序初始化完成");
}

void MainWindow::restoreWindowState()
{
    Logger::debug("恢复窗口状态");
    QSettings settings;
    restoreGeometry(settings.value("windowGeometry").toByteArray());
    restoreState(settings.value("windowState").toByteArray());
    m_floatVisible = settings.value("floatWindowVisible", true).toBool();
    Logger::info("窗口状态已恢复");
}

void MainWindow::saveWindowState()
{
    Logger::debug("保存窗口状态");
    QSettings settings;
    settings.setValue("windowGeometry", saveGeometry());
    settings.setValue("windowState", saveState());
    settings.setValue("floatWindowVisible", m_floatVisible);
    settings.setValue("floatWindowPos", m_floatWindow->pos());
    Logger::info("窗口状态已保存");
}

void MainWindow::showAdminWarning()
{
    Logger::warning("检测到需要管理员权限");
    int ret = QMessageBox::question(this, "权限提示",
                                    "需要管理员权限才能修改网络配置。\n"
                                    "是否立即获取权限？(否则部分功能将受限)",
                                    QMessageBox::Yes | QMessageBox::No);
    if (ret == QMessageBox::Yes)
    {
        Logger::info("用户选择获取管理员权限");
        if (!m_configManager->requestAdminPrivileges())
        {
            Logger::error("获取管理员权限失败");
            QMessageBox::warning(this, "警告", "获取管理员权限失败，部分功能将受限");
            disableAdminFunctions();
        }
    }
    else
    {
        Logger::info("用户选择不获取管理员权限");
        disableAdminFunctions();
    }
}

void MainWindow::disableAdminFunctions()
{
    Logger::warning("禁用管理员功能");
    ui->applyButton->setEnabled(false);
    ui->addButton->setEnabled(false);
    ui->updateButton->setEnabled(false);
    ui->deleteButton->setEnabled(false);
    ui->statusBar->showMessage("无管理员权限，部分功能受限", 2000);
}

void MainWindow::onConfigSelected(QListWidgetItem *item)
{
    if (!item)
    {
        Logger::debug("未选择有效配置项");
        return;
    }
    QString name = item->text();
    m_currentConfig = name;
    Logger::debug(QString("选择配置: %1").arg(name));
    QVariantMap config = m_configManager->configs().value(name);
    if (config.isEmpty())
    {
        Logger::warning(QString("无效配置: %1").arg(name));
        ui->statusBar->showMessage("无效配置: " + name, 2000);
        return;
    }
    //更新界面显示
    int index = ui->interfaceCombo->findText(config["interface"].toString());
    if (index >= 0)
    {
        ui->interfaceCombo->setCurrentIndex(index);
    }
    if (config["method"].toString() == "dhcp")
    {
        ui->dhcpRadio->setChecked(true);
        Logger::debug("配置使用DHCP模式");
    }
    else
    {
        ui->staticRadio->setChecked(true);
        Logger::debug("配置使用静态IP模式");
    }
    ui->ipEdit->setText(config["ip"].toString());
    ui->subnetEdit->setText(config["subnet"].toString());
    ui->gatewayEdit->setText(config["gateway"].toString());
    ui->primaryDnsEdit->setText(config["primary_dns"].toString());
    ui->secondaryDnsEdit->setText(config["secondary_dns"].toString());
    ui->statusBar->showMessage("已选择配置: " + name, 2000);
    Logger::info(QString("已加载配置: %1").arg(name));
}

void MainWindow::onInterfaceChanged(int index)
{
    if (index >= 0)
    {
        m_currentInterface = ui->interfaceCombo->itemText(index);
        Logger::debug(QString("选择网络接口: %1").arg(m_currentInterface));
        ui->statusBar->showMessage("已选择接口: " + m_currentInterface, 2000);
    }
    else
    {
        Logger::warning("无效的网络接口索引");
    }
}

void MainWindow::updateInterfaces()
{
    Logger::debug("更新网络接口列表");
    ui->interfaceCombo->clear();
    QStringList interfaces = m_configManager->getNetworkInterfaces();
    if (interfaces.isEmpty())
    {
        Logger::warning("未找到可用的网络接口");
    }
    else
    {
        Logger::info(QString("找到 %1 个网络接口").arg(interfaces.size()));
    }
    ui->interfaceCombo->addItems(interfaces);
    if (!interfaces.isEmpty())
    {
        updateConfigList();
    }
    ui->statusBar->showMessage("网络接口列表已更新", 2000);
    Logger::info("网络接口列表更新完成");
}

void MainWindow::onIpMethodToggled(bool checked)
{
    Q_UNUSED(checked);
    bool isDhcp = ui->dhcpRadio->isChecked();
    Logger::debug(QString("IP方法切换: %1").arg(isDhcp ? "DHCP" : "静态IP"));
    ui->ipEdit->setEnabled(!isDhcp);
    ui->subnetEdit->setEnabled(!isDhcp);
    ui->gatewayEdit->setEnabled(!isDhcp);
    ui->primaryDnsEdit->setEnabled(!isDhcp);
    ui->secondaryDnsEdit->setEnabled(!isDhcp);
}

void MainWindow::onAddConfig()
{
    Logger::info("开始添加新配置");
    bool ok;
    QString name = QInputDialog::getText(this, "添加配置", "请输入配置名称:",
                                         QLineEdit::Normal, "", &ok);
    if (!ok || name.isEmpty())
    {
        Logger::debug("用户取消添加配置或输入为空");
        return;
    }
    if (m_configManager->configs().contains(name))
    {
        Logger::warning(QString("配置名称已存在: %1").arg(name));
        QMessageBox::critical(this, "错误", "该配置名称已存在！");
        return;
    }
    if (ui->interfaceCombo->currentIndex() < 0)
    {
        Logger::warning("未选择网络接口");
        QMessageBox::critical(this, "错误", "请先选择网络接口！");
        return;
    }
    QString interface = ui->interfaceCombo->currentText();
    QString displayName = QString("[%1] %2").arg(interface.split(' ').first()).arg(name);
    QVariantMap config = getCurrentFormConfig();
    if (!validateIpConfig(config))
    {
        Logger::warning("IP配置验证失败");
        return;
    }
    if (m_configManager->addConfig(displayName, config))
    {
        if (m_configManager->saveConfigs())
        {
            Logger::info(QString("配置添加成功: %1").arg(displayName));
            updateConfigList(); // 更新所有配置列表
            m_currentConfig = displayName;
            ui->statusBar->showMessage("已添加配置: " + displayName, 2000);
            QMessageBox::information(this, "成功", QString("配置 '%1' 已添加！").arg(displayName));
        }
        else
        {
            Logger::error("保存配置文件失败");
            QMessageBox::critical(this, "错误", "保存配置失败，请检查文件权限");
        }
    }
    else
    {
        Logger::error("添加配置失败");
    }
}

void MainWindow::onUpdateConfig()
{
    Logger::info("开始更新配置");
    if (m_currentConfig.isEmpty())
    {
        Logger::warning("未选择要更新的配置");
        QMessageBox::critical(this, "错误", "请先选择一个配置！");
        return;
    }
    if (ui->interfaceCombo->currentIndex() < 0)
    {
        Logger::warning("未选择网络接口");
        QMessageBox::critical(this, "错误", "请先选择网络接口！");
        return;
    }
    QString interface = ui->interfaceCombo->currentText();
    QString oldName = m_currentConfig;
    //更新配置名称以包含接口前缀
    QString newName;
    if (oldName.contains("] "))
    {
        newName = QString("[%1] %2").arg(interface.split(' ').first())
                  .arg(oldName.split("] ").last());
    }
    else
    {
        newName = QString("[%1] %2").arg(interface.split(' ').first()).arg(oldName);
    }
    QVariantMap config = getCurrentFormConfig();
    if (!validateIpConfig(config))
    {
        Logger::warning("IP配置验证失败");
        return;
    }
    if (m_configManager->updateConfig(oldName, newName, config))
    {
        if (m_configManager->saveConfigs())
        {
            Logger::info(QString("配置更新成功: %1 -> %2").arg(oldName).arg(newName));
            updateConfigList(); // 更新所有配置列表
            m_currentConfig = newName;
            ui->statusBar->showMessage("已更新配置: " + newName, 2000);
            QMessageBox::information(this, "成功", QString("配置 '%1' 已更新！").arg(newName));
        }
        else
        {
            Logger::error("保存配置文件失败");
            QMessageBox::critical(this, "错误", "保存配置失败，请检查文件权限");
        }
    }
    else
    {
        Logger::error("更新配置失败");
    }
}

void MainWindow::onDeleteConfig()
{
    Logger::info("开始删除配置");
    if (m_currentConfig.isEmpty())
    {
        Logger::warning("未选择要删除的配置");
        QMessageBox::critical(this, "错误", "请先选择一个配置！");
        return;
    }
    if (QMessageBox::question(this, "确认",
                              QString("确定要删除配置 '%1' 吗？").arg(m_currentConfig))
            == QMessageBox::Yes)
    {
        Logger::debug(QString("用户确认删除配置: %1").arg(m_currentConfig));
        QString interface = m_configManager->configs().value(m_currentConfig)["interface"].toString();
        if (m_configManager->removeConfig(m_currentConfig))
        {
            if (m_configManager->saveConfigs())
            {
                Logger::info(QString("配置删除成功: %1").arg(m_currentConfig));
                m_currentConfig.clear();
                updateConfigList(); // 更新所有配置列表
                clearFields();
                ui->statusBar->showMessage("配置已删除", 2000);
                QMessageBox::information(this, "成功", "配置已删除！");
            }
            else
            {
                Logger::error("保存配置文件失败");
                QMessageBox::critical(this, "错误", "保存配置失败，请检查文件权限");
            }
        }
        else
        {
            Logger::error("删除配置失败");
        }
    }
    else
    {
        Logger::debug("用户取消删除配置");
    }
}

void MainWindow::onApplyConfig()
{
    Logger::info("开始应用配置");
    if (m_currentConfig.isEmpty())
    {
        Logger::warning("未选择要应用的配置");
        QMessageBox::critical(this, "错误", "请先选择一个配置！");
        return;
    }
    QVariantMap config = m_configManager->configs().value(m_currentConfig);
    if (config.isEmpty())
    {
        Logger::error("无效的配置");
        QMessageBox::critical(this, "错误", "无效的配置！");
        return;
    }
    Logger::debug(QString("应用配置: %1").arg(m_currentConfig));
    if (!m_configManager->applyConfig(config))
    {
        Logger::error("应用配置失败");
        QMessageBox::critical(this, "错误", "应用配置失败！");
    }
    else
    {
        Logger::info("配置应用请求已发送");
    }
}

QVariantMap MainWindow::getCurrentFormConfig() const
{
    QVariantMap config;
    config["interface"] = ui->interfaceCombo->currentText();
    config["method"] = ui->dhcpRadio->isChecked() ? "dhcp" : "static";
    config["ip"] = ui->ipEdit->text();
    config["subnet"] = ui->subnetEdit->text();
    config["gateway"] = ui->gatewayEdit->text();
    config["primary_dns"] = ui->primaryDnsEdit->text();
    config["secondary_dns"] = ui->secondaryDnsEdit->text();
    Logger::debug(QString("获取当前表单配置: 方法=%1, IP=%2").arg(config["method"].toString()).arg(config["ip"].toString()));
    return config;
}

bool MainWindow::validateIpConfig(const QVariantMap &config)
{
    if (config["method"].toString() == "static")
    {
        Logger::debug("验证静态IP配置");
        //验证IP地址
        if (config["ip"].toString().isEmpty())
        {
            Logger::warning("IP地址不能为空");
            QMessageBox::critical(this, "错误", "IP地址不能为空");
            return false;
        }
        //验证子网掩码
        if (config["subnet"].toString().isEmpty())
        {
            Logger::warning("子网掩码不能为空");
            QMessageBox::critical(this, "错误", "子网掩码不能为空");
            return false;
        }
        //验证IP和子网掩码格式
        QRegExp ipRegex("^(\\d{1,3}\\.){3}\\d{1,3}$");
        if (!ipRegex.exactMatch(config["ip"].toString()))
        {
            Logger::warning(QString("IP地址格式不正确: %1").arg(config["ip"].toString()));
            QMessageBox::critical(this, "错误", "IP地址格式不正确");
            return false;
        }
        if (!ipRegex.exactMatch(config["subnet"].toString()))
        {
            Logger::warning(QString("子网掩码格式不正确: %1").arg(config["subnet"].toString()));
            QMessageBox::critical(this, "错误", "子网掩码格式不正确");
            return false;
        }
        //如果有网关，验证网关格式
        if (!config["gateway"].toString().isEmpty() && !ipRegex.exactMatch(config["gateway"].toString()))
        {
            Logger::warning(QString("默认网关格式不正确: %1").arg(config["gateway"].toString()));
            QMessageBox::critical(this, "错误", "默认网关格式不正确");
            return false;
        }
        //验证DNS格式
        if (!config["primary_dns"].toString().isEmpty() && !ipRegex.exactMatch(config["primary_dns"].toString()))
        {
            Logger::warning(QString("首选DNS格式不正确: %1").arg(config["primary_dns"].toString()));
            QMessageBox::critical(this, "错误", "首选DNS格式不正确");
            return false;
        }
        if (!config["secondary_dns"].toString().isEmpty() && !ipRegex.exactMatch(config["secondary_dns"].toString()))
        {
            Logger::warning(QString("备用DNS格式不正确: %1").arg(config["secondary_dns"].toString()));
            QMessageBox::critical(this, "错误", "备用DNS格式不正确");
            return false;
        }
    }
    else
    {
        Logger::debug("DHCP配置无需验证");
    }
    Logger::info("IP配置验证通过");
    return true;
}

void MainWindow::updateConfigList()
{
    Logger::debug("更新所有配置列表");
    ui->configList->clear();
    QMap<QString, QVariantMap> configs = m_configManager->configs();
    // 遍历所有配置并添加到列表中
    for (auto it = configs.begin(); it != configs.end(); ++it)
    {
        ui->configList->addItem(it.key());
    }
    Logger::info(QString("显示 %1 个配置").arg(configs.size()));
    // 更新快捷菜单
    updateQuickMenu();
}

void MainWindow::clearFields()
{
    Logger::debug("清空表单字段");
    ui->ipEdit->clear();
    ui->subnetEdit->clear();
    ui->gatewayEdit->clear();
    ui->primaryDnsEdit->clear();
    ui->secondaryDnsEdit->clear();
    ui->dhcpRadio->setChecked(true);
}

void MainWindow::setupTrayIcon()
{
    Logger::info("初始化系统托盘图标");
    m_trayIcon->setIcon(QIcon(":/images/images/icon.png"));
    m_trayIcon->setToolTip(MAIN_WINDOW_TITLE);
    //先确保创建菜单对象
    if (!m_quickMenu)
    {
        Logger::debug("创建快速应用配置菜单");
        m_quickMenu = new QMenu("快速应用配置", this);
    }
    QMenu *trayMenu = new QMenu(this);
    QAction *showAction = trayMenu->addAction("显示主窗口");
    connect(showAction, &QAction::triggered, this, &MainWindow::showNormal);
    QAction *floatAction = trayMenu->addAction("显示/隐藏悬浮球");
    floatAction->setCheckable(true);
    floatAction->setChecked(m_floatVisible);
    connect(floatAction, &QAction::toggled, this, &MainWindow::toggleFloatWindow);
    //初始化快速配置子菜单
    m_quickMenu = trayMenu->addMenu("快速应用配置");
    updateQuickMenu();
    QAction *autostartAction = trayMenu->addAction("开机自启动");
    autostartAction->setCheckable(true);
    autostartAction->setChecked(m_autostart);
    connect(autostartAction, &QAction::toggled, this, &MainWindow::toggleAutostart);
    trayMenu->addSeparator();
    QAction *quitAction = trayMenu->addAction("退出");
    connect(quitAction, &QAction::triggered, qApp, &QCoreApplication::quit);
    m_trayIcon->setContextMenu(trayMenu);
    connect(m_trayIcon, &QSystemTrayIcon::activated, this, &MainWindow::onTrayIconActivated);
    m_trayIcon->show();
    Logger::info("系统托盘图标初始化完成");
}

void MainWindow::toggleFloatWindow(bool visible)
{
    Logger::info(QString("设置悬浮窗可见性: %1").arg(visible ? "显示" : "隐藏"));
    m_floatVisible = visible;
    QSettings().setValue("floatWindowVisible", m_floatVisible);
    if (m_floatVisible)
    {
        m_floatWindow->show();
    }
    else
    {
        m_floatWindow->hide();
    }
}

void MainWindow::toggleAutostart(bool enabled)
{
    Logger::info(QString("设置开机自启动: %1").arg(enabled ? "启用" : "禁用"));
    QSettings settings("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run", QSettings::NativeFormat);
    if (enabled)
    {
        QString appPath = QDir::toNativeSeparators(QCoreApplication::applicationFilePath());
        settings.setValue(APP_NAME, QString("\"%1\" --minimized").arg(appPath));
    }
    else
    {
        settings.remove(APP_NAME);
    }
    m_autostart = enabled;
    ui->statusBar->showMessage(enabled ? "已启用开机启动" : "已禁用开机启动", 2000);
}

void MainWindow::updateQuickMenu()
{
    if (!m_quickMenu)
    {
        Logger::warning("快速菜单未初始化");
        return;
    }
    Logger::debug("更新快速应用菜单");
    m_quickMenu->clear();
    // 获取所有网络接口
    QStringList interfaces = m_configManager->getNetworkInterfaces();
    if (interfaces.isEmpty())
    {
        Logger::debug("无可用网络接口");
        QAction *noInterfaceAction = m_quickMenu->addAction("无可用网络接口");
        noInterfaceAction->setEnabled(false);
        return;
    }
    // 获取所有保存的配置
    QMap<QString, QVariantMap> configs = m_configManager->configs();
    // 为每个接口创建子菜单
    for (const QString &interface : interfaces)
    {
        QString cleanInterface = interface.split(" (").first().trimmed();
        // 获取当前接口的配置
        QVariantMap currentConfig = getCurrentNetworkConfig(cleanInterface);
        // 创建接口子菜单
        QMenu *interfaceMenu = m_quickMenu->addMenu(cleanInterface);
        // 添加"当前配置"项
        QString configTitle;
        if (currentConfig["method"].toString() == "dhcp")
        {
            configTitle = "DHCP自动获取";
        }
        else
        {
            configTitle = QString("静态IP: %1").arg(currentConfig["ip"].toString());
        }
        QAction *currentAction = interfaceMenu->addAction(configTitle);
        currentAction->setCheckable(true);
        currentAction->setChecked(true);
        currentAction->setEnabled(false); // 当前配置不可点击
        interfaceMenu->addSeparator();
        // 添加该接口的所有保存的配置
        bool hasConfigs = false;
        for (auto it = configs.begin(); it != configs.end(); ++it)
        {
            QString configInterface = m_configManager->cleanInterfaceName(it.value()["interface"].toString());
            if (configInterface == cleanInterface)
            {
                QAction *action = interfaceMenu->addAction(it.key());
                action->setCheckable(true);
                action->setChecked(compareConfigs(currentConfig, it.value()));
                connect(action, &QAction::triggered, [this, config = it.value()]()
                {
                    Logger::info(QString("从快速菜单应用配置: %1").arg(config["interface"].toString()));
                    if (m_configManager->applyConfig(config))
                    {
                        ui->statusBar->showMessage("配置已应用", 2000);
                        // 更新菜单状态
                        QTimer::singleShot(100, this, &MainWindow::updateQuickMenu);
                    }
                });
                hasConfigs = true;
            }
        }
        if (!hasConfigs)
        {
            QAction *noConfigAction = interfaceMenu->addAction("无保存的配置");
            noConfigAction->setEnabled(false);
        }
    }
    // 如果配置较多，添加"更多配置"选项
    if (configs.size() > 8)
    {
        m_quickMenu->addSeparator();
        QAction *moreAction = m_quickMenu->addAction("更多配置...");
        connect(moreAction, &QAction::triggered, this, &MainWindow::showNormal);
    }
    Logger::info("快速应用菜单更新完成");
}

bool MainWindow::isDhcpEnabled(const QString &dhcpOutput)
{
    // 方法3：逐行解析（最可靠的方式）
    QStringList lines = dhcpOutput.split('\n');
    for (const QString &line : lines)
    {
        if (line.trimmed().startsWith("DHCP enabled:"))
        {
            QStringList parts = line.split(':');
            if (parts.size() >= 2)
            {
                QString value = parts[1].trimmed().toLower();
                return (value == "yes" || value == "是");
            }
        }
    }
    return false;
}

QVariantMap MainWindow::getCurrentNetworkConfig(const QString &InterfaceName)
{
    Logger::debug("获取当前网卡的网络配置");
    QVariantMap currentConfig;
    QString normalizedInterface = InterfaceName.split('\r').first().trimmed();
    if (normalizedInterface.contains("("))
    {
        normalizedInterface = normalizedInterface.split("(").first().trimmed();
    }
    currentConfig["interface"] = normalizedInterface;
    Logger::debug(QString("查询接口配置: %1").arg(normalizedInterface));
    // 检测DHCP状态
    QProcess dhcpProcess;
    dhcpProcess.start("netsh", QStringList() << "interface" << "ip" << "show" << "config" << QString("name=\"%1\"").arg(normalizedInterface));
    dhcpProcess.waitForFinished();
    QString dhcpOutput = QString::fromLocal8Bit(dhcpProcess.readAllStandardOutput());
    bool isDhcp = isDhcpEnabled(dhcpOutput);
    Logger::debug(QString("接口 DHCP 状态: %1").arg(isDhcp ? "启用" : "禁用"));
    //获取IP配置信息
    QProcess ipProcess;
    ipProcess.start("netsh", QStringList() << "interface" << "ip" << "show" << "addresses" << QString("name=\"%1\"").arg(normalizedInterface));
    ipProcess.waitForFinished();
    QString ipOutput = QString::fromLocal8Bit(ipProcess.readAllStandardOutput());
    QRegularExpression ipRegex(R"(IP [Aa]ddress\s*:\s*([0-9.]+))");
    QRegularExpression subnetRegex(R"(Subnet [Pp]refix[^\n]+mask\s+([0-9.]+))");
    QRegularExpression gatewayRegex(R"(Default [Gg]ateway\s*:\s*([0-9.]+))");
    QRegularExpressionMatch ipMatch = ipRegex.match(ipOutput);
    if (ipMatch.hasMatch())
    {
        currentConfig["ip"] = ipMatch.captured(1).trimmed();
        Logger::debug(QString("获取IP地址: %1").arg(currentConfig["ip"].toString()));
    }
    QRegularExpressionMatch subnetMatch = subnetRegex.match(ipOutput);
    if (subnetMatch.hasMatch())
    {
        currentConfig["subnet"] = subnetMatch.captured(1).trimmed();
        Logger::debug(QString("获取子网掩码: %1").arg(currentConfig["subnet"].toString()));
    }
    else
    {
        QRegularExpression altSubnetRegex(R"(Subnet Mask\s*:\s*([0-9.]+))");
        QRegularExpressionMatch altMatch = altSubnetRegex.match(ipOutput);
        if (altMatch.hasMatch())
        {
            currentConfig["subnet"] = altMatch.captured(1).trimmed();
            Logger::debug(QString("获取子网掩码(备用方式): %1").arg(currentConfig["subnet"].toString()));
        }
    }
    QRegularExpressionMatch gatewayMatch = gatewayRegex.match(ipOutput);
    if (gatewayMatch.hasMatch())
    {
        currentConfig["gateway"] = gatewayMatch.captured(1).trimmed();
        Logger::debug(QString("获取默认网关: %1").arg(currentConfig["gateway"].toString()));
    }
    if (currentConfig["subnet"].toString().isEmpty())
    {
        Logger::debug("尝试通过QNetworkInterface获取子网掩码");
        QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();
        for (const QNetworkInterface &interface : interfaces)
        {
            QString ifaceName = interface.name();
            if (ifaceName.contains("("))
            {
                ifaceName = ifaceName.split("(").first().trimmed();
            }
            if (ifaceName == normalizedInterface)
            {
                for (const QNetworkAddressEntry &entry : interface.addressEntries())
                {
                    if (entry.ip().protocol() == QAbstractSocket::IPv4Protocol && !entry.ip().isNull())
                    {
                        if (currentConfig["ip"].toString().isEmpty())
                        {
                            currentConfig["ip"] = entry.ip().toString();
                            Logger::debug(QString("通过QNetworkInterface获取IP地址: %1").arg(currentConfig["ip"].toString()));
                        }
                        if (currentConfig["subnet"].toString().isEmpty())
                        {
                            currentConfig["subnet"] = entry.netmask().toString();
                            Logger::debug(QString("通过QNetworkInterface获取子网掩码: %1").arg(currentConfig["subnet"].toString()));
                        }
                        break;
                    }
                }
                break;
            }
        }
    }
    //修改方法判断逻辑
    if (isDhcp)
    {
        currentConfig["method"] = "dhcp";
        Logger::debug("确定为DHCP模式(通过DHCP状态检测)");
    }
    else
    {
        currentConfig["method"] = "static";
        Logger::debug("确定为静态IP模式");
    }
    Logger::info("当前网络配置获取完成");
    return currentConfig;
}

QVariantList MainWindow::getAllNetworkConfigs()
{
    Logger::debug("获取所有网络配置");
    QVariantList allConfigs;
    // 获取所有网络接口
    QStringList interfaces = m_configManager->getNetworkInterfaces();
    for (const QString &iface : interfaces)
    {
        QVariantMap currentConfig;
        QString ifaceName = iface.split(" (").first().trimmed(); // 提取接口名称
        currentConfig["interface"] = ifaceName;
        Logger::debug(QString("查询接口配置: %1").arg(ifaceName));
        // 检测DHCP状态
        QProcess dhcpProcess;
        dhcpProcess.start("netsh", QStringList() << "interface" << "ip" << "show" << "config" << QString("name=\"%1\"").arg(ifaceName));
        dhcpProcess.waitForFinished();
        QString dhcpOutput = QString::fromLocal8Bit(dhcpProcess.readAllStandardOutput());
        bool isDhcp = isDhcpEnabled(dhcpOutput);
        Logger::debug(QString("接口 DHCP 状态: %1").arg(isDhcp ? "启用" : "禁用"));
        // 获取IP配置信息
        QProcess ipProcess;
        ipProcess.start("netsh", QStringList() << "interface" << "ip" << "show" << "addresses" << QString("name=\"%1\"").arg(ifaceName));
        ipProcess.waitForFinished();
        QString ipOutput = QString::fromLocal8Bit(ipProcess.readAllStandardOutput());
        // 正则表达式匹配
        QRegularExpression ipRegex(R"(IP [Aa]ddress\s*:\s*([0-9.]+))");
        QRegularExpression subnetRegex(R"(Subnet [Pp]refix[^\n]+mask\s+([0-9.]+))");
        QRegularExpression gatewayRegex(R"(Default [Gg]ateway\s*:\s*([0-9.]+))");
        // 匹配IP
        QRegularExpressionMatch ipMatch = ipRegex.match(ipOutput);
        if (ipMatch.hasMatch())
        {
            currentConfig["ip"] = ipMatch.captured(1).trimmed();
            Logger::debug(QString("获取IP地址: %1").arg(currentConfig["ip"].toString()));
        }
        // 匹配子网掩码
        QRegularExpressionMatch subnetMatch = subnetRegex.match(ipOutput);
        if (subnetMatch.hasMatch())
        {
            currentConfig["subnet"] = subnetMatch.captured(1).trimmed();
            Logger::debug(QString("获取子网掩码: %1").arg(currentConfig["subnet"].toString()));
        }
        // 匹配默认网关
        QRegularExpressionMatch gatewayMatch = gatewayRegex.match(ipOutput);
        if (gatewayMatch.hasMatch())
        {
            currentConfig["gateway"] = gatewayMatch.captured(1).trimmed();
            Logger::debug(QString("获取默认网关: %1").arg(currentConfig["gateway"].toString()));
        }
        // 确定配置类型
        currentConfig["method"] = isDhcp ? "dhcp" : "static";
        Logger::debug(QString("确定为[%1]模式").arg(isDhcp ? "DHCP" : "静态IP"));
        // 将当前配置添加到结果列表
        allConfigs.append(currentConfig);
    }
    Logger::info("所有网络配置获取完成");
    return allConfigs;
}


bool MainWindow::compareConfigs(const QVariantMap &current, const QVariantMap &saved)
{
    QString currentInterface = ConfigManager::cleanInterfaceName(current["interface"].toString());
    QString savedInterface = ConfigManager::cleanInterfaceName(saved["interface"].toString());
    if (currentInterface != savedInterface)
    {
        Logger::debug(QString("接口不匹配: %1 != %2").arg(currentInterface).arg(savedInterface));
        return false;
    }
    //如果是 DHCP 配置，只需比较接口和方法
    if (saved["method"].toString() == "dhcp")
    {
        Logger::debug("比较DHCP配置");
        QString saved_interface = m_configManager->cleanInterfaceName(saved["interface"].toString());
        return current["method"].toString() == "dhcp" &&
               current["interface"].toString() == saved_interface;
    }
    //静态 IP 配置需要比较所有字段
    Logger::debug("比较静态IP配置");
    return current["ip"].toString() == saved["ip"].toString() &&
           current["subnet"].toString() == saved["subnet"].toString() &&
           current["gateway"].toString() == saved["gateway"].toString();
}

void MainWindow::showFloatWindowMenu(const QPoint &pos)
{
    Logger::debug("显示悬浮窗上下文菜单");
    // 获取所有网络接口
    QStringList interfaces = m_configManager->getNetworkInterfaces();
    QMenu menu;
    // 为每个接口创建子菜单
    for (const QString &interface : interfaces)
    {
        QString cleanInterface = interface.split(" (").first().trimmed();
        // 获取当前接口的配置
        QVariantMap currentConfig = getCurrentNetworkConfig(cleanInterface);
        // 创建接口子菜单
        QMenu *interfaceMenu = menu.addMenu(cleanInterface);
        // 添加"当前配置"项
        QString configTitle;
        if (currentConfig["method"].toString() == "dhcp")
        {
            configTitle = "DHCP自动获取";
        }
        else
        {
            configTitle = QString("静态IP: %1").arg(currentConfig["ip"].toString());
        }
        QAction *currentAction = interfaceMenu->addAction(configTitle);
        currentAction->setCheckable(true);
        currentAction->setChecked(true);
        currentAction->setEnabled(false); // 当前配置不可点击
        interfaceMenu->addSeparator();
        // 添加该接口的所有保存的配置
        bool hasConfigs = false;
        QMap<QString, QVariantMap> configs = m_configManager->configs();
        for (auto it = configs.begin(); it != configs.end(); ++it)
        {
            QString configInterface = m_configManager->cleanInterfaceName(it.value()["interface"].toString());
            if (configInterface == cleanInterface)
            {
                QAction *action = interfaceMenu->addAction(it.key());
                action->setCheckable(true);
                action->setChecked(compareConfigs(currentConfig, it.value()));
                connect(action, &QAction::triggered, [this, config = it.value()]()
                {
                    Logger::info(QString("从悬浮窗菜单应用配置: %1").arg(config["interface"].toString()));
                    if (m_configManager->applyConfig(config))
                    {
                        ui->statusBar->showMessage("配置已应用", 2000);
                    }
                });
                hasConfigs = true;
            }
        }
        if (!hasConfigs)
        {
            QAction *noConfigAction = interfaceMenu->addAction("无保存的配置");
            noConfigAction->setEnabled(false);
        }
    }
    menu.addSeparator();
    // 添加其他功能项
    QAction *topAction = menu.addAction("置顶显示");
    topAction->setCheckable(true);
    topAction->setChecked(m_floatWindow->windowFlags() & Qt::WindowStaysOnTopHint);
    connect(topAction, &QAction::toggled, [this](bool checked)
    {
        Logger::info(QString("设置悬浮窗置顶: %1").arg(checked ? "是" : "否"));
        Qt::WindowFlags flags = m_floatWindow->windowFlags();
        if (checked)
        {
            flags |= Qt::WindowStaysOnTopHint;
        }
        else
        {
            flags &= ~Qt::WindowStaysOnTopHint;
        }
        m_floatWindow->setWindowFlags(flags);
        m_floatWindow->show();
    });
    menu.addSeparator();
    menu.addAction("显示主窗口", this, &MainWindow::showNormal);
    menu.addAction("退出", qApp, &QCoreApplication::quit);
    menu.exec(pos);
    Logger::debug("悬浮窗上下文菜单已显示");
}





void MainWindow::onTrayIconActivated(QSystemTrayIcon::ActivationReason reason)
{
    if (reason == QSystemTrayIcon::DoubleClick)
    {
        Logger::debug("双击托盘图标，显示主窗口");
        showNormal();
        activateWindow();
    }
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    Logger::info("主窗口关闭事件");
    saveWindowState();
    hide();
    m_trayIcon->showMessage(MAIN_WINDOW_TITLE,
                            "程序仍在后台运行，点击托盘图标可重新打开",
                            QSystemTrayIcon::Information,
                            2000);
    Logger::debug("主窗口已隐藏，程序在后台运行");
    event->ignore();
}

void MainWindow::showTrayMessage(const QString &title, const QString &message)
{
    Logger::info(QString("显示托盘消息: %1 - %2").arg(title).arg(message));
    m_trayIcon->showMessage(title, message, QSystemTrayIcon::Information, 2000);
}
