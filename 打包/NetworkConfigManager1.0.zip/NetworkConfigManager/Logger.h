#ifndef LOGGER_H
#define LOGGER_H

#include <QObject>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <QMutex>
#include <QDir>

class Logger : public QObject
{
    Q_OBJECT

public:
    // 日志等级枚举
    enum LogLevel
    {
        DEBUG = 0,
        INFO,
        WARNING,
        ERROR,
        CRITICAL
    };

    // 获取Logger单例
    static Logger *instance()
    {
        static QMutex mutex;
        QMutexLocker locker(&mutex);
        static Logger* instance = nullptr;
        if (!instance)
        {
            instance = new Logger();
        }
        return instance;
    }

    // 初始化日志系统
    bool init(const QString& logDir = "", const QString& logFilePrefix = "app")
    {
        QMutexLocker locker(&m_mutex);
        // 确定日志目录
        QString dirPath = logDir.isEmpty() ? QDir::currentPath() + "/logs" : logDir;
        QDir dir(dirPath);
        if (!dir.exists())
        {
            if (!dir.mkpath(dirPath))
            {
                return false;
            }
        }
        // 创建日志文件路径
        QString dateStr = QDateTime::currentDateTime().toString("yyyyMMdd");
        QString logFilePath = dirPath + "/" + logFilePrefix + "_" + dateStr + ".log";
        // 打开日志文件
        m_logFile.setFileName(logFilePath);
        if (!m_logFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
        {
            return false;
        }
        m_logStream.setDevice(&m_logFile);
        return true;
    }

    // 记录日志
    void log(LogLevel level, const QString& message)
    {
        QMutexLocker locker(&m_mutex);
        if (!m_logFile.isOpen())
        {
            return;
        }
        QString levelStr;
        switch (level)
        {
            case DEBUG:
                levelStr = "DEBUG";
                break;
            case INFO:
                levelStr = "INFO";
                break;
            case WARNING:
                levelStr = "WARNING";
                break;
            case ERROR:
                levelStr = "ERROR";
                break;
            case CRITICAL:
                levelStr = "CRITICAL";
                break;
            default:
                levelStr = "UNKNOWN";
                break;
        }
        QString timeStr = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz");
        QString logEntry = QString("[%1] [%2] %3\n").arg(timeStr, levelStr, message);
        m_logStream << logEntry;
        m_logStream.flush();
    }

    // 便捷日志方法
    static void debug(const QString& message)
    {
        instance()->log(DEBUG, message);
    }

    static void info(const QString& message)
    {
        instance()->log(INFO, message);
    }

    static void warning(const QString& message)
    {
        instance()->log(WARNING, message);
    }

    static void error(const QString& message)
    {
        instance()->log(ERROR, message);
    }

    static void critical(const QString& message)
    {
        instance()->log(CRITICAL, message);
    }

    //关闭日志文件
    void shutdown()
    {
        QMutexLocker locker(&m_mutex);
        if (m_logFile.isOpen())
        {
            m_logStream.flush();
            m_logFile.close();
        }
    }

private:
    explicit Logger(QObject *parent = nullptr) : QObject(parent) {}
    ~Logger()
    {
        shutdown();
    }

    Logger(const Logger &) = delete;
    Logger &operator=(const Logger &) = delete;

    QFile m_logFile;
    QTextStream m_logStream;
    QMutex m_mutex;
};

#endif // LOGGER_H
