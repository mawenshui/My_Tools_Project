#ifndef FLOATWINDOW_H
#define FLOATWINDOW_H

#include <QWidget>
#include <QPoint>
#include <QColor>

class FloatWindow : public QWidget
{
    Q_OBJECT
public:
    explicit FloatWindow(QWidget *parent = nullptr);

    // 外观设置
    void setBackgroundColor(const QColor &color);
    void setText(const QString &text);
    void setTextColor(const QColor &color);
    void setDraggable(bool enabled);

    // 状态获取
    bool isOnTop() const;
    bool isDraggable() const;
    QColor backgroundColor() const;
    QString text() const;
    QColor textColor() const;

signals:
    void doubleClicked();
    void showContextMenu(const QPoint &pos);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void mouseDoubleClickEvent(QMouseEvent *event) override;
    void contextMenuEvent(QContextMenuEvent *event) override;
    void enterEvent(QEvent *event) override;
    void leaveEvent(QEvent *event) override;

private:
    QPoint m_dragPosition;
    bool m_dragging;
    bool m_draggable;
    QColor m_backgroundColor;
    QColor m_textColor;
    QString m_displayText;
    bool m_hovered;

    void updateHoverState(bool hovered);
};

#endif // FLOATWINDOW_H
