#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSystemTrayIcon>
#include <QListWidgetItem>
#include <QDir>
#include <QNetworkInterface>
#include <QProcess>
#include <QRegularExpression>
#include <QSharedMemory>
#include <QCheckBox>
#include <QPointer>

#include "Logger.h"
#include "configmanager.h"
#include "floatwindow.h"

const QString MAIN_WINDOW_TITLE = "IP配置管理器";
const QString APP_NAME = "NetworkConfigManager";

namespace Ui
{
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void closeEvent(QCloseEvent *event) override;
//    bool eventFilter(QObject *watched, QEvent *event) override;

private slots:
    // 配置管理
    void onConfigSelected(QListWidgetItem *item);
    void onAddConfig();
    void onUpdateConfig();
    void onDeleteConfig();
    void onApplyConfig();
    void updateConfigList();

    // 网络接口
    void onInterfaceChanged(int index);
    void updateInterfaces();

    // IP方法
    void onIpMethodToggled(bool checked);

    // 浮动窗口
    void toggleFloatWindow(bool visible);
    void showFloatWindowMenu(const QPoint &pos);

    // 系统托盘
    void setupTrayIcon();
    void toggleAutostart(bool enabled);
    void showTrayMessage(const QString &title, const QString &message);
    void onTrayIconActivated(QSystemTrayIcon::ActivationReason reason);

    // 快速菜单
    void updateQuickMenu();

    // 辅助功能
    bool checkSingleInstance();
    void restoreWindowState();

private:
    Ui::MainWindow *ui;
    ConfigManager *m_configManager;
    QMenu *m_quickMenu;
    FloatWindow *m_floatWindow;
    QSystemTrayIcon *m_trayIcon;
    QSharedMemory m_singleInstanceLock;

    bool m_floatVisible;
    bool m_autostart;
    QString m_currentConfig;
    QString m_currentInterface;

    // UI初始化
    void setupUi();
    void setupConnections();

    // 配置操作
    void clearFields();
    bool validateIpConfig(const QVariantMap &config);
    QVariantMap getCurrentNetworkConfig(const QString &InterfaceName);
    QVariantList getAllNetworkConfigs();
    bool compareConfigs(const QVariantMap &current, const QVariantMap &saved);

    // 工具方法
    QString getActiveConfigName() const;
    void saveWindowState();
    void showAdminWarning();
    void initializeApplication();
    void disableAdminFunctions();
    QVariantMap getCurrentFormConfig() const;
    bool isDhcpEnabled(const QString &dhcpOutput);
};

#endif // MAINWINDOW_H
