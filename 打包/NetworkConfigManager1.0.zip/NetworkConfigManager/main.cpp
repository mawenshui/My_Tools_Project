#include "mainwindow.h"
#include <QApplication>
#include <QSharedMemory>
#include <QMessageBox>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    //如果带--minimized参数启动，则最小化到托盘
    if (a.arguments().contains("--minimized"))
    {
        w.hide();
    }
    else
    {
        w.show();
    }
    return a.exec();
}
