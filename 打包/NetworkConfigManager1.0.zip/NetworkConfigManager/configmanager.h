#ifndef CONFIGMANAGER_H
#define CONFIGMANAGER_H

#include <QObject>
#include <QMap>
#include <QString>
#include <QVariantMap>
#include <QJsonObject>
#include <QJsonDocument>
#include <QMutex>
#include <QMutexLocker>
#include <QDateTime>
#include <QRegularExpression>

class ConfigManager : public QObject
{
    Q_OBJECT
public:
    explicit ConfigManager(QObject *parent = nullptr);
    ~ConfigManager();

    // 权限检查
    bool isAdmin() const;
    bool requestAdminPrivileges();

    // 配置管理
    bool loadConfigs();
    bool saveConfigs();
    QStringList getNetworkInterfaces(bool useCache = true);

    // 网络配置操作
    bool applyConfig(const QVariantMap &config);

    // 线程安全的配置访问
    QMap<QString, QVariantMap> configs() const;
    bool addConfig(const QString &name, const QVariantMap &config);
    bool updateConfig(const QString &oldName, const QString &newName, const QVariantMap &config);
    bool removeConfig(const QString &name);

    // 工具方法
    static QString cleanInterfaceName(const QString &rawName);
    bool validateConfig(const QVariantMap &config) const;

signals:
    void configApplied(bool success, const QString &message) const;
    void errorOccurred(const QString &error) const;
    void adminStatusChanged(bool isAdmin) const;

private:
    mutable QMutex m_mutex;
    QMap<QString, QVariantMap> m_configs;
    QString m_configFile;
    QStringList m_cachedInterfaces;
    QDateTime m_lastInterfaceUpdate;

    bool m_isAdmin;
    bool m_isSaving;

    bool checkAdminStatus();
    bool internalSaveConfigs();
    QString getNetshOutput(const QStringList &args) const;
};

#endif // CONFIGMANAGER_H
