#include "floatwindow.h"
#include <QPainter>
#include <QMouseEvent>
#include <QMenu>
#include <QApplication>
#include <QCursor>
#include <QDebug>

FloatWindow::FloatWindow(QWidget *parent)
    : QWidget(parent),
      m_dragging(false),
      m_draggable(true),
      m_backgroundColor(QColor(61, 219, 255)),
      m_textColor(Qt::black),
      m_displayText("IP"),
      m_hovered(false)
{
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint | Qt::Tool);
    setAttribute(Qt::WA_TranslucentBackground);
    setFixedSize(64, 64);
}

void FloatWindow::setBackgroundColor(const QColor &color)
{
    if (m_backgroundColor != color)
    {
        m_backgroundColor = color;
        update();
    }
}

void FloatWindow::setText(const QString &text)
{
    if (m_displayText != text)
    {
        m_displayText = text;
        update();
    }
}

void FloatWindow::setTextColor(const QColor &color)
{
    if (m_textColor != color)
    {
        m_textColor = color;
        update();
    }
}

void FloatWindow::setDraggable(bool enabled)
{
    m_draggable = enabled;
}

bool FloatWindow::isOnTop() const
{
    return windowFlags() & Qt::WindowStaysOnTopHint;
}

bool FloatWindow::isDraggable() const
{
    return m_draggable;
}

QColor FloatWindow::backgroundColor() const
{
    return m_backgroundColor;
}

QString FloatWindow::text() const
{
    return m_displayText;
}

QColor FloatWindow::textColor() const
{
    return m_textColor;
}

void FloatWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    // 绘制背景
    QColor bgColor = m_backgroundColor;
    if (m_hovered)
    {
        bgColor = bgColor.lighter(110); // 悬停时变亮
    }
    painter.setBrush(bgColor);
    painter.setPen(Qt::NoPen);
    painter.drawEllipse(rect().adjusted(5, 5, -5, -5));
    // 绘制文本
    painter.setPen(m_textColor);
    QFont font = painter.font();
    font.setPointSize(12);
    font.setBold(true);
    painter.setFont(font);
    painter.drawText(rect(), Qt::AlignCenter, m_displayText);
}

void FloatWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && m_draggable)
    {
        m_dragPosition = event->globalPos() - frameGeometry().topLeft();
        m_dragging = true;
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

void FloatWindow::mouseMoveEvent(QMouseEvent *event)
{
    if (m_dragging && (event->buttons() & Qt::LeftButton))
    {
        move(event->globalPos() - m_dragPosition);
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

void FloatWindow::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && m_dragging)
    {
        m_dragging = false;
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

void FloatWindow::mouseDoubleClickEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        emit doubleClicked();
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

void FloatWindow::contextMenuEvent(QContextMenuEvent *event)
{
    emit showContextMenu(event->globalPos());
    event->accept();
}

void FloatWindow::enterEvent(QEvent *event)
{
    Q_UNUSED(event);
    updateHoverState(true);
    setCursor(Qt::PointingHandCursor);
}

void FloatWindow::leaveEvent(QEvent *event)
{
    Q_UNUSED(event);
    updateHoverState(false);
    unsetCursor();
}

void FloatWindow::updateHoverState(bool hovered)
{
    if (m_hovered != hovered)
    {
        m_hovered = hovered;
        update();
    }
}
